# S. Praveen — Portfolio Site

A static HTML/CSS/JS portfolio for a Data Analyst / Financial Analyst profile,
built around a "financial ledger" visual concept: paper backgrounds, ruled
hairlines, monospace figures, and a navy/teal/brass palette.

## Files

```
index.html        Page structure and all copy
css/styles.css     All styling (design tokens are set as CSS variables at the top)
js/script.js       Mobile nav toggle + scroll-based active nav highlighting
images/            Your portrait (praveen-profile.jpg)
resume/            Put your resume PDF here (see below)
```

## Before you publish

1. **Add your resume.** Export your resume as a PDF, name it
   `S-Praveen-Resume.pdf`, and place it in the `resume/` folder. The
   "Download resume" button already points to `resume/S-Praveen-Resume.pdf`.
2. **Swap in real project links.** The three project cards currently link to
   your GitHub profile (`github.com/praveendell6334`) as a placeholder — once
   you push real repos, update each `.project-link` `href` in `index.html` to
   point at the specific repo.
3. **Add project screenshots (optional).** If you want visuals inside each
   project entry, add an `<img>` under `.project-col` and drop the screenshot
   in `images/`.

## Run locally

No build step needed — it's plain HTML/CSS/JS.

```bash
# from the project folder
python3 -m http.server 8000
# then open http://localhost:8000
```

## Deploy for free

**GitHub Pages**
1. Push this folder to a repo (e.g. `praveendell6334.github.io` for a root
   domain, or any repo name for a project page).
2. In the repo, go to Settings → Pages → set the source to the `main` branch,
   root folder.
3. Your site publishes at `https://praveendell6334.github.io/<repo-name>/`.

**Vercel**
1. Push the folder to a GitHub repo.
2. Import the repo at vercel.com → New Project.
3. Leave the framework preset as "Other" (it's static) and deploy — no build
   command needed.

## Customizing the design tokens

All colors and fonts are defined once, at the top of `css/styles.css`:

```css
:root {
  --paper:  #F6F3EC;  /* background */
  --ink:    #14202E;  /* primary text */
  --navy:   #0F1E33;  /* header, dark band, footer */
  --teal:   #0E6E63;  /* accent: links, underlines, active states */
  --brass:  #A9793F;  /* accent: credential tags, portrait file tab */
  ...
}
```

Change a value once here and it updates everywhere it's used.
